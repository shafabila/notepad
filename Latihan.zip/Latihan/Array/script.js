//1. menambah isi array
// var arr = [];
// arr[0] = "Sandhika";
// arr[1] = "Galih";
// arr[2] = "Ratna";
// arr[6] = "Sule";

// console.log(arr);

//2. menghapus isi array
// varr arr = ["Sandhik", "Galih", "Ratna"];
// arr[1] = undefined;
// console.log(arr);

//3. menampilkan isi array
var arr = ["Sandhika", "Galih", "Ratna", "Nofa", "Doddy"];

for( var i = 0; i < arr.length; i++ ) {
    console.log('mahasiswa ke ' + (i+1) + ' : ' + arr[i]);
}
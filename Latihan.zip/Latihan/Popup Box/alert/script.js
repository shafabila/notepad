alert('Halo');
alert('nama');
alert('saya');
alert('Sandhika Galih');
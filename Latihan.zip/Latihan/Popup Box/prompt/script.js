var nama = prompt('Masukkan Nama : ');
alert(nama);
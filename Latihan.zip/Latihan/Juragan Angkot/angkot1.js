var jmlAngkot = 10;
var noAngkot = 1;
while(noAngkot <= jmlAngkot) {
    console.log('Angkot No. ' + noAngkot + 'beroperasi dengan baik');
noAngkot++;
}
var nilaiAwal = 1;
while(nilaiAwal <= 10 ) {
    console.log('Hello world' + nilaiAwal+'x');
    nilaiAwal ++;
}
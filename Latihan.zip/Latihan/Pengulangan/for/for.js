for( var nilaiAwal = 1; nilaiAwal <= 10; nilaiAwal++){
    console.log('hello world ' + nilaiAwal + 'x');
}
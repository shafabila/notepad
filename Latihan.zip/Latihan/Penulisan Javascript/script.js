var x = 10;
console.log('Hello World!');
console.log('isi dari variable x adalah ' + x);